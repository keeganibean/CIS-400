﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TestingExercise
{
    /// <summary>
    /// Public enum to keep track of the result from the guesses
    /// </summary>
    public enum GuessResult
    {
        Correct,
        Wrong,
        Multiple,
        NotLetter
    }
}
