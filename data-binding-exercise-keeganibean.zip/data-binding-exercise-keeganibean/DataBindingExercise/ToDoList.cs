﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Collections.Specialized;
using System.ComponentModel;
using System.Text;

namespace DataBindingExercise
{
    /// <summary>
    /// Class representing a to do list
    /// </summary>
    public class ToDoList : ObservableCollection<ToDoItem>
    {
        /// <summary>
        /// Number of complete tasks in to do list
        /// </summary>
        public int CompleteCount
        {
            get
            {
                int numComplete = 0;
                foreach(ToDoItem item in this)
                {
                    if (item.Complete)
                    {
                        numComplete++;
                    }                   
                }
                return numComplete;
            }
        }

        /// <summary>
        /// Constructor for ToDoList
        /// Hooks up the collection changed listener
        /// </summary>
        public ToDoList()
        {
            CollectionChanged += CollectionChangedListener;
        }

        /// <summary>
        /// Number of incomplete tasks in to do list
        /// </summary>
        public int IncompleteCount
        {
            get
            {
                int numIncomplete = 0;
                foreach(ToDoItem item in this)
                {
                    if (!item.Complete)
                    {
                        numIncomplete++;
                    }
                }
                return numIncomplete;
            }
        }

        /// <summary>
        /// A listener for the collection change
        /// </summary>
        /// <param name="sender">objects sent</param>
        /// <param name="e">Notifications for changed properties</param>
        void CollectionChangedListener(object sender, NotifyCollectionChangedEventArgs e)
        {
            OnPropertyChanged(new PropertyChangedEventArgs("CompleteCount"));
            OnPropertyChanged(new PropertyChangedEventArgs("IncompleteCount"));
            switch (e.Action)
            {
                case NotifyCollectionChangedAction.Add:
                    foreach(ToDoItem item in e.NewItems)
                    {
                        item.PropertyChanged += CollectionItemChangedListener;
                    }
                    break;
                case NotifyCollectionChangedAction.Remove:
                    foreach(ToDoItem item in e.OldItems)
                    {
                        item.PropertyChanged -= CollectionItemChangedListener;
                    }
                    break;
                case NotifyCollectionChangedAction.Reset:
                    throw new NotImplementedException("NotifyCollectionChangedSction.Reset not supported");
            }
        }

        /// <summary>
        /// Event listener for the changed collection items
        /// </summary>
        /// <param name="sender">The object sent</param>
        /// <param name="e">The property changes</param>
        void CollectionItemChangedListener(object sender, PropertyChangedEventArgs e)
        {
            if(e.PropertyName == "Complete")
            {
                OnPropertyChanged(new PropertyChangedEventArgs("CompleteCount"));
                OnPropertyChanged(new PropertyChangedEventArgs("IncompleteCount"));
            }
        }
    }
}
