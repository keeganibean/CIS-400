# VectorModuleExercises
This is a starter project for an exercise in learning encapsulation techniques employed in C#. 

It is part of the Kansas State University "CIS 400 - Object-Oriented Implementation, Design, and Testing" course, and its accompanying textbook is available at [https://people.cs.ksu.edu/~nhb7817/cis400](https://people.cs.ksu.edu/~nhb7817/cis400)
