﻿using System;
using System.Collections.Generic;
using System.Text;

namespace VectorLibrary
{
    public struct Vector3
    {
        /// <summary>
        /// Doubles used for vector math
        /// </summary>
        public double X;
        public double Y;
        public double Z;

        /// <summary>
        /// Constructor for Vector3
        /// </summary>
        /// <param name="x"></param>
        /// <param name="y"></param>
        /// <param name="z"></param>
        public Vector3(double x, double y, double z)
        {
            X = x;
            Y = y;
            Z = z;
        }
    }
}
