﻿using System;
using System.IO;
using System.Net;
using System.Text.Json;
using System.Xml;

namespace WebApiExercise
{
    /// <summary>
    /// A class to run the program calling the Web API
    /// </summary>
    class Program
    {
        /// <summary>
        /// Main function running the web requests
        /// </summary>
        /// <param name="args">The arguments passed in</param>
        static void Main(string[] args)
        {
            /// <summary>
            /// A request to create from this url
            /// </summary>
            WebRequest request = WebRequest.Create("https://api.jokes.one/jod");

            /// <summary>
            /// Adding the application
            /// </summary>
            request.Headers.Add("Accept", "application/json");

            /// <summary>
            /// The response from the web
            /// </summary>
            WebResponse response = request.GetResponse();

            /// <summary>
            /// Reading the response stream
            /// </summary>
            using (Stream responseStream = response.GetResponseStream())
            {
                /// <summary>
                /// Read the document
                /// </summary>
                StreamReader reader = new StreamReader(responseStream);
                string tmp = reader.ReadToEnd();

                /// <summary>
                /// Using XML
                /// </summary>
                /* 
                Console.WriteLine(tmp);
                XmlDocument xDoc = new XmlDocument();
                xDoc.Load(responseStream);
                XmlNode node = xDoc.SelectSingleNode("/response/contents/jokes/joke/text");
                Console.WriteLine(node.InnerText);
                */

                /// <summary>
                /// Using Json
                /// </summary>
                JsonDocument jDoc = JsonSerializer.Deserialize<JsonDocument>(tmp);
                var contents = jDoc.RootElement.GetProperty("contents");
                var jokes = contents.GetProperty("jokes");
                var jokeWrapper = jokes[0];
                var joke = jokeWrapper.GetProperty("joke");
                var text = joke.GetProperty("text");
                Console.WriteLine(text);

                /// <summary>
                /// Citing the source of the joke
                /// </summary>
                var copyright = contents.GetProperty("copyright");    
                Console.WriteLine("Jokes provided by https://jokes.one");
                Console.WriteLine("Copyright: " + copyright);
            }
        }
    }
}
