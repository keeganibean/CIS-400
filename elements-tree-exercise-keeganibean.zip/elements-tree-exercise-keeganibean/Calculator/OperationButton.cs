﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Controls;

namespace Calculator
{
    /// <summary>
    /// Public class for the operation button handling
    /// </summary>
    public class OperationButton : Button
    {
        /// <summary>
        /// The operation this button performs
        /// </summary>
        public Operation Operation { get; set; } = Operation.None;
    }
}
