﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Calculator
{
    /// <summary>
    /// Interaction logic for DigitButton.xaml
    /// </summary>
    public partial class DigitButton : Button
    {
        /// <summary>
        /// Constructor for the DigitButton we have created
        /// </summary>
        public DigitButton()
        {
            InitializeComponent();
        }
    }
}
